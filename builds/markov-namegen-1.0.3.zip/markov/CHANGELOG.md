## 1.0.0
* Initial release

## 1.0.1
* Add a missed include.xml

## 1.0.2
* Fix directory structure so it actually works with haxelib

## 1.0.3
* Remove some unused methods and other minor code cleanup